package com.example.eventtracker;

public class Event {
    private int id;
    private String name;
    private String date;
    private String notes;

    public Event(int id, String name, String date, String notes) {
        this.id = id;
        this.name = name;
        this.date = date;
        this.notes = notes;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getDate() { return date; }
    public String getNotes() { return notes; }
}
