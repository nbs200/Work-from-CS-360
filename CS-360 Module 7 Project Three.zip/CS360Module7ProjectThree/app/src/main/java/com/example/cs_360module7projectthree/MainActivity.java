package com.example.eventtracker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import android.app.AlertDialog;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements EventAdapter.OnEventClickListener {

    private static final int SMS_PERMISSION_REQUEST = 100;

    private DatabaseHelper dbHelper;
    private RecyclerView recyclerView;
    private EventAdapter adapter;
    private List<Event> eventList = new ArrayList<>();

    private Button btnAddEvent, btnSendSms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);

        recyclerView = findViewById(R.id.recyclerViewEvents);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        adapter = new EventAdapter(eventList, this);
        recyclerView.setAdapter(adapter);

        btnAddEvent = findViewById(R.id.btnAddEvent);
        btnSendSms = findViewById(R.id.btnSendSms);

        loadEventsFromDb();

        btnAddEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showAddEventDialog();
            }
        });

        btnSendSms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkSmsPermissionAndSend();
            }
        });
    }

    private void loadEventsFromDb() {
        eventList.clear();
        Cursor cursor = dbHelper.getAllEvents();
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_EVENT_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_EVENT_NAME));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_EVENT_DATE));
                String notes = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_EVENT_NOTES));

                eventList.add(new Event(id, name, date, notes));
            } while (cursor.moveToNext());
            cursor.close();
        }
        adapter.notifyDataSetChanged();
    }

    private void showAddEventDialog() {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_event, null);
        final EditText etName = dialogView.findViewById(R.id.etEventName);
        final EditText etDate = dialogView.findViewById(R.id.etEventDate);
        final EditText etNotes = dialogView.findViewById(R.id.etEventNotes);

        new AlertDialog.Builder(this)
                .setTitle("Add Event")
                .setView(dialogView)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String name = etName.getText().toString().trim();
                        String date = etDate.getText().toString().trim();
                        String notes = etNotes.getText().toString().trim();

                        if (name.isEmpty()) {
                            Toast.makeText(MainActivity.this, "Name required", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        long result = dbHelper.addEvent(name, date, notes);
                        if (result != -1) {
                            loadEventsFromDb();
                            Toast.makeText(MainActivity.this, "Event added", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(MainActivity.this, "Error adding event", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // Called when user taps an event item (from adapter)
    @Override
    public void onEventClick(final Event event) {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_event, null);
        final EditText etName = dialogView.findViewById(R.id.etEventName);
        final EditText etDate = dialogView.findViewById(R.id.etEventDate);
        final EditText etNotes = dialogView.findViewById(R.id.etEventNotes);

        etName.setText(event.getName());
        etDate.setText(event.getDate());
        etNotes.setText(event.getNotes());

        new AlertDialog.Builder(this)
                .setTitle("Edit/Delete Event")
                .setView(dialogView)
                .setPositiveButton("Update", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String name = etName.getText().toString().trim();
                        String date = etDate.getText().toString().trim();
                        String notes = etNotes.getText().toString().trim();

                        dbHelper.updateEvent(event.getId(), name, date, notes);
                        loadEventsFromDb();
                        Toast.makeText(MainActivity.this, "Event updated", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNeutralButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dbHelper.deleteEvent(event.getId());
                        loadEventsFromDb();
                        Toast.makeText(MainActivity.this, "Event deleted", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ---------- SMS PERMISSION + SEND ----------

    private void checkSmsPermissionAndSend() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST);
        } else {
            sendSmsAlert();
        }
    }

    private void sendSmsAlert() {
        // In a real app, you’d use a user-provided phone number and dynamic message.
        String phoneNumber = "5551234567";
        String message = "Reminder: You have upcoming events in your Event Tracker app.";

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS alert sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST) {
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendSmsAlert();
            } else {
                Toast.makeText(this,
                        "SMS permission denied. App will continue without SMS alerts.",
                        Toast.LENGTH_LONG).show();
            }
        }
    }
}
